﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        double temp;

        public double fabs(double x)//绝对值
        {
            if (x < 0)
            {
                x = -x;
            }
            return x;
        }

        public double cbrt(double x)//立方根
        {
            if (x < 0)
            {
                x = -Math.Pow(-x, 1.0 / 3);
            }
            else
            {
                x = Math.Pow(x, 1.0 / 3);
            }
            return x;
        }

        public void fun2(double a, double b, double c)//ax^2+bx+c=0
        {
            double x1, x2, delta;
            string s1, s2;

            if (fabs(c) < 1e-15)//x(ax+b)=0
            {
                x1 = -b / a;
                textBox7.Text = textBox7.Text + "0\r\n" + x1.ToString() + "\r\n";
            }
            else
            {
                b /= a;
                c /= a;
                delta = b * b - 4 * c;
                if (delta > 0)
                {
                    x1 = (-b + Math.Sqrt(delta)) / 2;
                    x2 = (-b - Math.Sqrt(delta)) / 2;
                    s1 = x1.ToString() + "\r\n";
                    s2 = x2.ToString() + "\r\n";
                    textBox7.Text = textBox7.Text + s1 + s2;
                }
                else if (delta == 0)
                {
                    x1 = -b / 2;
                    s1 = x1.ToString() + "\r\n";
                    textBox7.Text = textBox7.Text + s1 + s1;
                }
                else
                {
                    x1 = -b / 2;
                    x2 = Math.Sqrt(-delta) / 2;
                    if (fabs(b) < 1e-15)
                    {
                        if (fabs(x2 - 1) < 1e-15)
                        {
                            textBox7.Text = textBox7.Text + "i\r\n-i\r\n";
                        }
                        else
                        {
                            s2 = fabs(x2 - 1) < 1e-15 ? "i\r\n" : x2.ToString() + "i\r\n";
                            textBox7.Text = textBox7.Text + s2 + "-" + s2;
                        }
                    }
                    else
                    {
                        s1 = x1.ToString();
                        s2 = fabs(x2 - 1) < 1e-15 ? "i\r\n" : x2.ToString() + "i\r\n";
                        textBox7.Text = textBox7.Text + s1 + "+" + s2 + s1 + "-" + s2;
                    }
                }
            }
        }

        public double fun3_subsidiary(double a, double b, double c, double d)//返回ax^3+bx^2+cx+d=0的一个实数根
        {
            double p, q, r, x, theta, delta;
            temp = a;
            a = b / temp;
            b = c / temp;
            c = d / temp;//x^3 + ax^2 + bx + c =0
            p = b - a * a / 3;
            q = c + a * (2 * a * a - 9 * b) / 27;
            p /= -3;
            q /= -2;
            delta = q * q - p * p * p;

            if (delta < 0)
            {
                r = p * Math.Sqrt(p);
                theta = Math.Acos(q / r) / 3;
                x = 2 * cbrt(r) * Math.Cos(theta) - a / 3;
            }
            else if (delta == 0)
            {
                x = -a / 3 + 2 * cbrt(q);
            }
            else
            {
                x = -a / 3 + cbrt(q + Math.Sqrt(delta)) + cbrt(q - Math.Sqrt(delta));//卡尔达诺公式
            }

            return x;
        }

        public void fun3(double a, double b, double c, double d)//ax^3+bx^2+cx+d=0
        {
            double x;
            if (fabs(d) < 1e-15)//x(ax^2+bx+c)=0
            {
                textBox7.Text = textBox7.Text + "0\r\n";
                fun2(a, b, c);//降次
            }
            else
            {
                x = fun3_subsidiary(a, b, c, d);
                textBox7.Text = textBox7.Text + x.ToString() + "\r\n";
                fun2(a, a * x + b, a * x * x + b * x + c);
            }
        }

        public void fun4(double a, double b, double c, double d, double e)//ax^4+bx^3+cx^2+dx+e=0
        {
            double y, p, q, r, delta, theta;
            string s1, s2;
            if (fabs(e) < 1e-15)//x(ax^3+bx^2+cx+d)=0
            {
                textBox7.Text = textBox7.Text + "0\r\n";
                fun3(a, b, c, d);
            }
            else
            {
                temp = a;
                a = b / temp;
                b = c / temp;
                c = d / temp;
                d = e / temp;
                if (a != 0 || c != 0)
                {
                    y = fun3_subsidiary(1, -b, a * c - 4 * d, 4 * b * d - a * a * d - c * c);//费拉里法
                    p = Math.Sqrt(a * a / 4 - b + y);
                    q = (a * y - 2 * c) / (a * a - 4 * b + 4 * y);
                    fun2(1, a / 2 - p, y / 2 - p * q);
                    fun2(1, a / 2 + p, y / 2 + p * q);
                }
                else if (fabs(b) < 1e-15)//x^4+d=0
                {
                    if (d < 0)
                    {
                        y = Math.Pow(-d, 0.25);
                        s1 = y.ToString() + "\r\n";
                        s2 = (fabs(y - 1) < 1e-15) ? "i\r\n" : y.ToString() + "i\r\n";
                        textBox7.Text = textBox7.Text + s1 + "-" + s1 + s2 + "-" + s2;
                    }
                    else
                    {
                        y = Math.Pow(d / 4, 0.25);
                        s1 = y.ToString();
                        s2 = (fabs(y - 1) < 1e-15) ? "i\r\n" : y.ToString() + "i\r\n";
                        textBox7.Text = textBox7.Text + s1 + "+" + s2 + s1 + "-" + s2 + "-" + s1 + "+" + s2 + "-" + s1 + "-" + s2;
                    }
                }
                else //x^4+bx^2+d=0
                {
                    delta = b * b - 4 * d;
                    if (delta > 0)
                    {
                        y = b - Math.Sqrt(delta);
                        if (y > 0)
                        {
                            y = Math.Sqrt(y / 2);
                            s1 = (fabs(y - 1) < 1e-15) ? "i\r\n" : y.ToString() + "i\r\n";
                            textBox7.Text = textBox7.Text + s1 + "-" + s1;
                        }
                        else
                        {
                            y = Math.Sqrt(-y / 2);
                            s1 = y.ToString() + "\r\n";
                            textBox7.Text = textBox7.Text + s1 + "-" + s1;
                        }

                        y = b + Math.Sqrt(delta);
                        if (y > 0)
                        {
                            y = Math.Sqrt(y / 2);
                            s1 = (fabs(y - 1) < 1e-15) ? "i\r\n" : y.ToString() + "i\r\n";
                            textBox7.Text = textBox7.Text + s1 + "-" + s1;
                        }
                        else
                        {
                            y = Math.Sqrt(-y / 2);
                            s1 = y.ToString() + "\r\n";
                            textBox7.Text = textBox7.Text + s1 + "-" + s1;
                        }
                    }
                    else if (delta == 0)
                    {
                        if (b < 0)
                        {
                            y = Math.Sqrt(-b / 2);
                            s1 = y.ToString() + "\r\n";
                            textBox7.Text = textBox7.Text + s1 + s1 + "-" + s1 + "-" + s1;
                        }
                        else
                        {
                            y = Math.Sqrt(b / 2);
                            s1 = (fabs(y - 1) < 1e-15) ? "i\r\n" : y.ToString() + "i\r\n";
                            textBox7.Text = textBox7.Text + s1 + s1 + "-" + s1 + "-" + s1;
                        }
                    }
                    else
                    {
                        r = Math.Sqrt(b * b - delta) / 2;
                        theta = Math.Atan2(Math.Sqrt(-delta) / 2, -b / 2) / 2;
                        p = Math.Sqrt(r) * Math.Cos(theta);
                        q = Math.Sqrt(r) * Math.Sin(theta);
                        s1 = p.ToString();
                        s2 = q.ToString();
                        if (p * q < 0)
                        {
                            s1 = fabs(p).ToString();
                            s2 = (fabs(fabs(q) - 1) < 1e-15) ? "i\r\n" : fabs(q).ToString() + "i\r\n";
                            textBox7.Text = textBox7.Text + s1 + "-" + s2 + "-" + s1 + "+" + s2;
                        }
                        else
                        {
                            s1 = fabs(p).ToString();
                            s2 = (fabs(fabs(q) - 1) < 1e-15) ? "i\r\n" : fabs(q).ToString() + "i\r\n";
                            textBox7.Text = textBox7.Text + s1 + "+" + s2 + "-" + s1 + "-" + s2;
                        }
                        theta = Math.Atan2(-Math.Sqrt(-delta) / 2, -b / 2) / 2;
                        p = Math.Sqrt(r) * Math.Cos(theta);
                        q = Math.Sqrt(r) * Math.Sin(theta);
                        if (p * q < 0)
                        {
                            s1 = fabs(p).ToString();
                            s2 = (fabs(fabs(q) - 1) < 1e-15) ? "i\r\n" : fabs(q).ToString() + "i\r\n";
                            textBox7.Text = textBox7.Text + s1 + "-" + s2 + "-" + s1 + "+" + s2;
                        }
                        else
                        {
                            s1 = fabs(p).ToString();
                            s2 = (fabs(fabs(q) - 1) < 1e-15) ? "i\r\n" : fabs(q).ToString() + "i\r\n";
                            textBox7.Text = textBox7.Text + s1 + "+" + s2 + "-" + s1 + "-" + s2;
                        }
                    }
                }
            }
        }

        public double fun5_subsidiary(double a, double b, double c, double d, double e, double x)//牛顿迭代法
        {
            double derivative;
            temp = x * (x * (x * (x + a) + b) + c) + d;
            derivative = x * (x * (x * (5 * x + 4 * a) + 3 * b) + 2 * c) + d;
            x = x - (temp * x + e) / derivative;
            return x;
        }

        public void fun5(double a, double b, double c, double d, double e)//x^5+ax^4+bx^3+cx^2+dx+e=0
        {
            double x, i;
            if (fabs(e) < 1e-15)
            {
                textBox7.Text += "0\r\n";
                fun4(1, a, b, c, d);
            }
            else
            {
                if (d != 0)
                {
                    x = 0;
                }
                else if (5 + 4 * a + 3 * b + 2 * c + d != 0)
                {
                    x = 1;
                }
                else if (5 - 4 * a + 3 * b - 2 * c + d != 0)
                {
                    x = -1;
                }
                else if (80 + 32 * a + 12 * b + 4 * c + d != 0)
                {
                    x = 2;
                }
                else//防止导数等于0
                {
                    x = 2.718;
                }

                for (i = 0; i < 50; i++)
                {
                    x = fun5_subsidiary(a, b, c, d, e, x);
                }

                textBox7.Text = x.ToString() + "\r\n";
                fun4(1, x + a, x * x + a * x + b, x * x * x + a * x * x + b * x + c, temp);//降次
            }
        }

        public void judgement(double a, double b, double c, double d, double e, double f)
        {
            if (a != 0)//五次
            {
                textBox7.Text = "x1,x2,x3,x4,x5:\r\n";
                fun5(b / a, c / a, d / a, e / a, f / a);
            }
            else if (b != 0)//四次
            {
                textBox7.Text = "x1,x2,x3,x4:\r\n";
                fun4(b, c, d, e, f);
            }
            else if (c != 0)//三次
            {
                textBox7.Text = "x1,x2,x3:\r\n";
                fun3(c, d, e, f);
            }
            else if (d != 0)//二次
            {
                textBox7.Text = "x1,x2:\r\n";
                fun2(d, e, f);
            }
            else if (e != 0)//一次
            {
                f /= (-e);
                textBox7.Text = "x = " + f.ToString();
            }
            else//常值
            {
                if (f == 0)
                {
                    textBox7.Text = "任意复数";
                }
                else
                {
                    textBox7.Text = "无解";
                }
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)//解方程
        {
            double a1, b1, c1, d1, e1, f1;
            textBox7.Text = "";
            a1 = Convert.ToDouble(textBox1.Text);
            b1 = Convert.ToDouble(textBox2.Text);
            c1 = Convert.ToDouble(textBox3.Text);
            d1 = Convert.ToDouble(textBox4.Text);
            e1 = Convert.ToDouble(textBox5.Text);
            f1 = Convert.ToDouble(textBox6.Text);
            judgement(a1, b1, c1, d1, e1, f1);
        }

        private void button2_Click(object sender, EventArgs e)//清除
        {
            textBox1.Text = "0";
            textBox2.Text = "0";
            textBox3.Text = "0";
            textBox4.Text = "0";
            textBox5.Text = "0";
            textBox6.Text = "0";
            textBox7.Text = "";
        }
    }
}
